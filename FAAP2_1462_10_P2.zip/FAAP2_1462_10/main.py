"""
Created on Sun Oct 01 20:23:59 2017

@author: profesores faa
"""

from Datos import Datos
import EstrategiaParticionado
import Clasificador
import numpy as np
from plotModel import plotModel
import matplotlib.pyplot as plt

data = 'ConjuntosDatos/example2.data'
dataset=Datos(data)
estrategia= EstrategiaParticionado.ValidacionCruzada(10)
clasificador=Clasificador.ClasificadorVecinosProximos(11,True)
errores=clasificador.validacion(estrategia,dataset,clasificador,laplace=1, seed=None)
print("Probabilidad de error: ",errores)
media = np.mean(errores)
d_tipica = np.std(np.transpose(np.array(errores)), axis=0)
print("Promedio de error: ", media)
print("Desviacion Tipica: ", d_tipica)

#plot
ii=estrategia.listaPartic[-1].indicesTrain
plotModel(dataset.datos[ii,0],dataset.datos[ii,1],dataset.datos[ii,-1]!=0,clasificador,"Frontera",dataset.nominalAtributos,dataset.diccionarios, dataset.extraeDatos(estrategia.listaPartic[-1].indicesTrain))
plt.figure()
plt.plot(dataset.datos[dataset.datos[:,-1] == 0,0], dataset.datos[dataset.datos[:,-1] == 0,1], 'bo')
plt.plot(dataset.datos[dataset.datos[:,-1] == 1,0], dataset.datos[dataset.datos[:,-1] == 1,1], 'ro')
plt.show()